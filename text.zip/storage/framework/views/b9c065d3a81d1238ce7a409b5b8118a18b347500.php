<!DOCTYPE html>
<html>
<?php echo $__env->make('dashboard.partials.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition skin-blue sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
    <?php echo $__env->make('dashboard.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Left side column. contains the sidebar -->
    <?php echo $__env->make('dashboard.partials.left_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <?php echo $__env->make('dashboard.partials.content_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Main content -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make('dashboard.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Control Sidebar -->
    <?php echo $__env->make('dashboard.partials.right_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php echo $__env->make('dashboard.partials.footer_script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('scripts'); ?>
<?php echo $__env->yieldContent('footer'); ?>
</body>
</html>
