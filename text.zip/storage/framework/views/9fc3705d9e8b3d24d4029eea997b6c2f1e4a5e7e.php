<?php echo $__env->make('dashboard.partials.formErrorMessage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
    <label for="name" class="col-sm-3 control-label">First Name <span>*</span></label>
    <div class="col-sm-9">
        <?php echo Form::text('first_name',$value= null, $attributes = ['class'=>'form-control','placeholder'=>'First Name','required'=>true,'autofocus'=>true]); ?>

        <?php if($errors->has('first_name')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('first_name')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>
<div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
    <label for="name" class="col-sm-3 control-label">Last Name <span>*</span></label>
    <div class="col-sm-9">
        <?php echo Form::text('last_name',$value= null, $attributes = ['class'=>'form-control','placeholder'=>'Last Name','required'=>true,'autofocus'=>true]); ?>

        <?php if($errors->has('last_name')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('last_name')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>
<div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
    <label for="email" class="col-sm-3 control-label">Email <span>*</span></label>
    <div class="col-sm-9">
        <?php echo Form::email('email',$value= null, $attributes = ['class'=>'form-control','placeholder'=>'Email','required'=>true]); ?>

        <?php if($errors->has('email')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>





