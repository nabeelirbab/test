<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <i class="fa fa-user fa-3x" style="border-radius: 30px; border:1px solid #fff;color: #fff;padding: 4px 10px;"></i>
                
            </div>
            <div class="pull-left info">
                <p><?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>
        <!-- search form -->
        <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
                <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
            </div>
        </form>
        <!-- /.search form -->
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li><a href="<?php echo e(url('/dashboard')); ?>"> <i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
            </li>
			
				    <li class="treeview">
                <a href="#">
                    <i class="fa fa-users"></i>
                    <span>Manage Users</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
           <li><a href="<?php echo e(action('Dashboard\UserController@create')); ?>"><i class="fa fa-circle-o"></i> New User</a></li>
          <li>
             <a href="#"><i class="fa fa-circle-o"></i> View Users  <i class="fa fa-angle-left pull-right"></i></a>
             <ul class="treeview-menu">
             <li><a href="<?php echo e(action('Dashboard\UserController@index')); ?>"><i class="fa fa-angle-double-right"></i> All Users</a></li>
             <li><a href="<?php echo e(action('Dashboard\UserController@customers')); ?>"><i class="fa fa-angle-double-right"></i> Job seeker </a></li>
             <li><a href="<?php echo e(action('Dashboard\UserController@owners')); ?>"><i class="fa fa-angle-double-right"></i> Employer </a></li>
             <li><a href="<?php echo e(action('Dashboard\UserController@admin')); ?>"><i class="fa fa-angle-double-right"></i> Admins </a></li>
            </ul>
  </li>
 </ul>
</li>
	    <li class="treeview">
                <a href="#">
                  <i class="fa fa-building-o" aria-hidden="true"></i>
                    <span>Company</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
           <li><a href="<?php echo e(action('Dashboard\CompanyController@create')); ?>"><i class="fa fa-circle-o"></i> New Company</a></li>
             <li><a href="<?php echo e(action('Dashboard\CompanyController@index')); ?>"><i class="fa fa-circle-o"></i> All Company</a></li>
       </ul>
     </li>
	 
	    <li class="treeview">
                <a href="#">
                    <i class="fa fa-list-alt" aria-hidden="true"></i>
                    <span>Category</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
           <li><a href="<?php echo e(action('Dashboard\CatagoryController@create')); ?>"><i class="fa fa-angle-double-right"></i> New Category</a></li>
		    <li><a href="<?php echo e(action('Dashboard\CatagoryController@index')); ?>"><i class="fa fa-angle-double-right"></i> View Category</a></li>
          <li>
             <a href="#"><i class="fa fa-circle-o"></i> SubCategory <i class="fa fa-angle-left pull-right"></i></a>
             <ul class="treeview-menu">
             <li><a href="<?php echo e(action('Dashboard\SubCatagoryController@create')); ?>"><i class="fa fa-angle-double-right"></i> Add SubCategory</a></li>
             <li><a href="<?php echo e(action('Dashboard\SubCatagoryController@index')); ?>"><i class="fa fa-angle-double-right"></i> View SubCategory</a></li>
         
            </ul>
  </li>
 </ul>
</li>
   
	    <li class="treeview">
                <a href="#">
                   <i class="fa fa-cog" aria-hidden="true"></i>
                    <span>Web Setting</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
           
          <li>
             <a href="#"><i class="fa fa-circle-o"></i> Manage Users <i class="fa fa-angle-left pull-right"></i></a>
             <ul class="treeview-menu">
             <li><a href="<?php echo e(action('Dashboard\UserController@index')); ?>"><i class="fa fa-angle-double-right"></i> All Users</a></li>
             <li><a href="<?php echo e(action('Dashboard\UserController@customers')); ?>"><i class="fa fa-angle-double-right"></i> Job seeker </a></li>
             <li><a href="<?php echo e(action('Dashboard\UserController@owners')); ?>"><i class="fa fa-angle-double-right"></i> Employer </a></li>
             <li><a href="<?php echo e(action('Dashboard\UserController@admin')); ?>"><i class="fa fa-angle-double-right"></i> Admins </a></li>
            </ul>
  </li>
 </ul>
</li>
           
         
			
	
			

</ul>
</section>
<!-- /.sidebar -->
</aside>