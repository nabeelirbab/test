<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
    <head>
        <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

        <!-- Styles -->
    </head>
    <body>
       <div class="container">
    <h2>Upload Photo</h2>
	<div class="row">
	<div class="col-md-3">
	<h3>Tittle</h3><br>
	<h3>Image</h3>
	</div>
	   <div class="col-sm-9">
 <?php echo Form::open(['action'=>['ImageController@store'],'method'=>'post','class'=>'form-horizontal','files'=>true,'enctype'=>'multipart/form-data']); ?>

           
                        <div class="form-group <?php echo e($errors->has('bar_name') ? ' has-error' : ''); ?>">
                            <label for="bar_name" class="col-sm-3 control-label">Title <span>*</span></label>
                            <div class="col-sm-9">
                                <?php echo Form::text('titel',$value= null, $attributes = ['class'=>'form-control','placeholder'=>'Title','required'=>true,'autofocus'=>true]); ?>

                                <?php if($errors->has('bar_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('titel')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
						
						<br>
						 <div class="form-group <?php echo e($errors->has('logo') ? ' has-error' : ''); ?>">
                            <label class="col-sm-3 control-label"> Logo</label>
                            <div class="col-sm-9">
                                <input type="file" name="photo"  class="input-photo form-control" accept="image/*">
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('photo') ? ' has-error' : ''); ?>">
                            <div class="col-sm-9 col-sm-offset-3 preview-images">
                            </div>
                        </div>
						   <div class="box-footer clearfix">
                <div class="row">
                    <div class="col-sm-8">
                        <span class="pull-right">
                            
                             &nbsp;
                             <button type="submit" class="btn btn-info ">Upload</button>
                        </span>
                    </div>
                </div>
             </div>
			
			
            <?php echo Form::close(); ?>

  </div>
  </div>
 
</div>
  <script>
        function readURL(input) {
            if (input.files && input.files.length>0) {
                for (var i=0;i<input.files.length;i++){
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $('.preview-images').append('<img width="200" height="200" style="border-radius:10%" src="'+ e.target.result +'" id="image_upload_preview" class="img-responsive img-thumbnail">')
                    };
                    reader.readAsDataURL(input.files[i]);
                }

            }
        }
        $(".input-photo").change(function () {
            $('.preview-images').html('');
            readURL(this);
        });
		  </script>
    </body>
</html>
