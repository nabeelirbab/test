<?php if(isset($breadcrumb) && is_array($breadcrumb)): ?>
<section class="content-header">
    <h1>
    Posts
    
        <small>Manage Posts</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>

    </ol>
</section>
<?php endif; ?>