<?php echo $__env->make('dashboard.partials.formErrorMessage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
    <label for="name" class="col-sm-3 control-label">Company Name <span>*</span></label>
    <div class="col-sm-9">
        <?php echo Form::text('company_Name',$value= null, $attributes = ['class'=>'form-control','placeholder'=>'First Name','required'=>true,'autofocus'=>true]); ?>

        <?php if($errors->has('company_Name')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('company_Name')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>
<div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
    <label for="name" class="col-sm-3 control-label">Company Phone <span>*</span></label>
    <div class="col-sm-9">
        <?php echo Form::number('company_Phone',$value= null, $attributes = ['class'=>'form-control','placeholder'=>'Company_Phone','required'=>true,'autofocus'=>true]); ?>

        <?php if($errors->has('company_Phone')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('company_Phone')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>
<div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
    <label for="email" class="col-sm-3 control-label">Company Address<span>*</span></label>
    <div class="col-sm-9">
        <?php echo Form::text('company_Address',$value= null, $attributes = ['class'=>'form-control','placeholder'=>'Company Address,','required'=>true]); ?>

        <?php if($errors->has('company_Address')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('company_Address')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>
<div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
    <label for="email" class="col-sm-3 control-label">No.Employee <span>*</span></label>
    <div class="col-sm-9">
        <?php echo Form::text('no_Employe',$value= null, $attributes = ['class'=>'form-control','placeholder'=>'No of Employee','required'=>true]); ?>

        <?php if($errors->has('no_Employe')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('no_Employe')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>
<div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
    <label for="email" class="col-sm-3 control-label">Timing<span>*</span></label>
    <div class="col-sm-9">
        <?php echo Form::text('timing',$value= null, $attributes = ['class'=>'form-control','placeholder'=>'Company Timing','required'=>true]); ?>

        <?php if($errors->has('timing')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('timing')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>
<div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
    <label for="email" class="col-sm-3 control-label">Timing<span>*</span></label>
    <div class="col-sm-9">
        <?php echo Form::date('establish_Time',$value= null, $attributes = ['class'=>'form-control','placeholder'=>'Company Timing','required'=>true]); ?>

        <?php if($errors->has('establish_Time')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('establish_Time')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>






