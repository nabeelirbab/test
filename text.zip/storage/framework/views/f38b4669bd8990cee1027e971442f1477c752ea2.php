<?php echo $__env->make('dashboard.partials.formErrorMessage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
    <label for="limt" class="col-sm-3 control-label">Category Name <span>*</span></label>
    <div class="col-sm-9">
        <?php echo Form::text('category_Name',$value= null, $attributes = ['class'=>'form-control','placeholder'=>'Category','required'=>true,'autofocus'=>true]); ?>

        <?php if($errors->has('category_Name')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('category_Name')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>







