<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo e($title); ?></h3>
                <div class="box-tools pull-right">
                    <a href="<?php echo e(action('Dashboard\UserController@create')); ?>" type="button" class="btn btn-box-tool"  data-toggle="tooltip" title="New User">
                        <i class="fa fa-plus"></i>
                    </a>
                    <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                        <i class="fa fa-minus"></i>
                    </button>
                </div>
            </div>
            <div class="box-body">
                <?php echo $__env->make('dashboard.partials.formErrorMessage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <table class="table table-bordered">
                    <tbody><tr>
                        <th style="width: 10px">#</th>
                        <th>First Name</th>
						<th>Last Name</th>
                        <th>Email</th>

                        <th>Role</th>
                        <th>Join At</th>
                        <th>Profile Last Updated</th>
                        <th>Auction</th>
                    </tr>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($user->first_name); ?> </td>
							<td><?php echo e($user->last_name); ?> </td>
                            <td><?php echo e($user->email); ?></td>

                           <td><span class="label <?php echo e($user->user_type =='Admin'?"label-success": ($user->user_type =='Job Seeker'?'label-info':'label-primary')); ?>"><?php echo e(ucfirst($user->user_type)); ?></span></td>
                             <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                            <td><?php echo e($user->created_at->diffForHumans()); ?></td>

                            <td>
                                <a href="<?php echo e(action('Dashboard\UserController@show',$user->id)); ?>" class="btn btn-xs btn-info" data-toggle="tooltip"  data-original-title="View Profile"><i class="fa fa-eye"></i> </a>
                            <span class="pull-right">
							
                                    <a href="<?php echo e(action('Dashboard\UserController@edit',$user->id)); ?>" class="btn btn-xs btn-warning" data-toggle="tooltip"  data-original-title="Edit"><i class="fa fa-edit"></i> </a>
                                    <?php echo Form::open(['action'=>['Dashboard\UserController@destroy',$user->id],'method'=>'delete','style'=>'display:inline;']); ?>

                                        <input type="hidden" class="delete_permanent" name="delete_permanent" value="0">
                                    <button type="button" class="btn btn-xs btn-danger btn-delete-user" data-toggle="tooltip"  data-original-title="Delete"><i class="fa fa-trash-o"></i></button>
                                    <?php echo Form::close(); ?>

                            </span>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($users->isEmpty()): ?>
                        <tr>
                            <td colspan="9">
                                <p class="alert alert-warning text-center">
                                    No active users found.
                                </p>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
                <?php echo e($users->links()); ?>

            </div>
            <!-- /.box-footer-->
        </div>
        <!-- /.box -->
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script>
        $(document).on('click','.btn-delete-user', function () {
            var form = $(this).parents('form:first');

            $.confirm({
                icon: 'fa fa-trash-o',
                title: 'Delete User!',
                closeIcon: true,
                animation: 'rotate',
                closeAnimation: 'rotate',
                content: 'Are you want to delete this user?',
                confirmButton: 'Yes',
                cancelButton: 'No',
                confirmButtonClass: 'btn-danger',
                cancelButtonClass: 'btn-info',
                confirm: function(){
                    if(!$('input#__delete_permanent').is(':checked')){
                        form.find('input.delete_permanent').attr('value','1');
                    }
                    form.submit();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>