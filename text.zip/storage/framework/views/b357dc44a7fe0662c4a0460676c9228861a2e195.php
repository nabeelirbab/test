<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Category</h3>
                <div class="box-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                        <i class="fa fa-minus"></i></button>
                </div>
            </div>
            <?php echo Form::model($user,['action'=>['Dashboard\CatagoryController@update',$user->id],'method'=>'PATCH','class'=>'form-horizontal','files'=>true,'enctype'=>'multipart/form-data']); ?>

            <div class="box-body">
                <div class="row">
                    <div class="col-sm-6 col-sm-offset-2">
                        <?php echo $__env->make('dashboard.partials.formErrorMessage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo $__env->make('dashboard.category._formCreateEdit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    </div>
                </div>

            </div>

            <!-- /.box-body -->
            <div class="box-footer clearfix">
                <div class="row">
                    <div class="col-sm-6 col-sm-offset-2">
                        <span class="pull-right">
                             <a href="<?php echo e(action('Dashboard\CatagoryController@index')); ?>" class="btn btn-default">Cancel</a>
                             &nbsp;
                             <button type="submit" class="btn btn-info ">Update</button>
                        </span>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>

                    <!-- /.box-footer-->

        <!-- /.box -->
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>