<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Edit Users</h3>
                <div class="box-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                        <i class="fa fa-minus"></i></button>
                </div>
            </div>
            <?php echo Form::model($user,['action'=>['Dashboard\UserController@update',$user->id],'method'=>'PATCH','class'=>'form-horizontal','files'=>true,'enctype'=>'multipart/form-data']); ?>

            <div class="box-body">
                <div class="row">
                    <div class="col-sm-6 col-sm-offset-2">
                        <?php echo $__env->make('dashboard.partials.formErrorMessage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						
                        <?php echo $__env->make('dashboard.users._formCreateEdit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					
                        <div class="form-group">
                            <label class="col-sm-3 control-label">User Type</label>
                            <div class="col-sm-9" style="padding-top: 5px;">
                                <label>
                                    <input type="radio" <?php echo e($user->user_type!='employe' || $user->user_type!='admin' ?'checked':''); ?> name="user_type" value="Job seeker" class="minimal" >
                                    User
                                </label>
                                    &nbsp;
                                <label>
                                    <input type="radio" <?php echo e($user->user_type =='employe'?'checked':''); ?> name="user_type" value="employe" class="minimal" >
                                   Moderator
                                </label>
                                &nbsp;
                                <label>
                                    <input type="radio" <?php echo e($user->user_type =='admin'?'checked':''); ?> name="user_type" value="admin" class="minimal" >
                                    Admin
                                </label>
                            </div>
                        </div>
						
                        </div>
                    </div>
                </div>

            </div>

            <!-- /.box-body -->
            <div class="box-footer clearfix">
                <div class="row">
                    <div class="col-sm-6 col-sm-offset-2">
                        <span class="pull-right">
                             <a href="<?php echo e(action('Dashboard\UserController@index')); ?>" class="btn btn-default">Cancel</a>
                             &nbsp;
                             <button type="submit" class="btn btn-info ">Update</button>
                        </span>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>

                    <!-- /.box-footer-->
        </div>
        <!-- /.box -->
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script>
        $(function () {
            try {
                //iCheck for checkbox and radio inputs
                $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
                    checkboxClass: 'icheckbox_minimal-blue',
                    radioClass: 'iradio_minimal-blue'
                });
                //Red color scheme for iCheck
                $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
                    checkboxClass: 'icheckbox_minimal-red',
                    radioClass: 'iradio_minimal-red'
                });
            }catch (e){
                console.error(e);
            }

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>