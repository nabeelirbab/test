<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
    <head>
        <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

        <!-- Styles -->
    </head>
    <body>
       <div class="container">
      <h2>Upload Photo</h2>

             <?php $__currentLoopData = $userss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			 <div class="row">
      <div class="col-md-4">
			
			     <img src="<?php echo e(asset('image/'.$user_info->photo)); ?>" alt="<?php echo e($user_info->titel); ?>" width="200" height="200" style="margin-bottom: 15px;border-radius:10%">
               </div>  
			   <div class="col-md-3">
               <h3><?php echo e($user_info->titel); ?></h3>
			   </div>
			         </div> 
		 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>
  <script>
        function readURL(input) {
            if (input.files && input.files.length>0) {
                for (var i=0;i<input.files.length;i++){
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $('.preview-images').append('<img width="200" height="200" style="border-radius:10%" src="'+ e.target.result +'" id="image_upload_preview" class="img-responsive img-thumbnail">')
                    };
                    reader.readAsDataURL(input.files[i]);
                }

            }
        }
        $(".input-photo").change(function () {
            $('.preview-images').html('');
            readURL(this);
        });
		  </script>
    </body>
</html>
