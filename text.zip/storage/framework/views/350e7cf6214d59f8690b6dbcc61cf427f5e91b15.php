<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Add New Users</h3>
                <div class="box-tools pull-right">
                    <a href="<?php echo e(action('Dashboard\UserController@index')); ?>" type="button" class="btn btn-box-tool" data-toggle="tooltip" title="User list">
                        <i class="fa fa-list"></i></a>
                    <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                        <i class="fa fa-minus"></i></button>
                </div>
            </div>
            <?php echo Form::open(['action'=>['Dashboard\UserController@store'],'method'=>'post','class'=>'form-horizontal','files'=>true,'enctype'=>'multipart/form-data']); ?>

            <div class="box-body">
                <div class="row">
                    <div class="col-sm-6 col-sm-offset-2">
                        <?php echo $__env->make('dashboard.users._formCreateEdit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<div class="form-group <?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                  <label for="email" class="col-sm-3 control-label">Phone No<span>*</span></label>
                    <div class="col-sm-9">
                         <?php echo Form::number('phone',$value= null, $attributes = ['class'=>'form-control','placeholder'=>'Phone No','required'=>true]); ?>

                      <?php if($errors->has('phone')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('phone')); ?></strong>
                        </span>
                      <?php endif; ?>
                  </div>
                </div>
					<div class="form-group " id="company" style="display:none">
                            <label for="country" class="col-sm-3 control-label">Company<span>*</span></label>
                            <div class="col-sm-9">
                                <select class="form-control" name="company_id" id="company_id">
                                   
                                      <?php $__currentLoopData = $userss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option  value="<?php echo e($user_info->id); ?>"><?php echo e($user_info->company_Name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">User Type</label>
                            <div class="col-sm-9" style="padding-top: 5px;">
                                <label>
                                    <input type="radio"  name="user_type" id="Seeker" value="Job Seeker" class="minimal" checked >
                                    Job Seeker
                                </label>
                                       &nbsp;
                                <label>
                                    <input type="radio"  name="user_type" value="Employer" class="minimal" id="Employer" >
                                  Employer
                                </label>
                                &nbsp;
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
                <div class="row">
                    <div class="col-sm-8">
                        <span class="pull-right">
                             <button type="reset" class="btn btn-default">Cancel</button>
                             &nbsp;
                             <button type="submit" class="btn btn-info ">Create</button>
                        </span>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>

                    <!-- /.box-footer-->
        </div>
        <!-- /.box -->
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<!-- date-range-picker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
<script src="<?php echo e(asset('assets/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
    <script>
	

$(document).ready(function(){
	
    $('input[name=user_type]').on('change', function(){
    var n = $(this).val();
    switch(n)
    {
            case 'Employer':
                 $('#company').show();
                  break;
            case 'Job Seeker':
                $('#company').hide();
                  break;
            
        }
    });
});
       
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>