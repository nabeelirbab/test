                 <?php echo $__env->make('dashboard.partials.formErrorMessage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                   <div class="form-group ">
                      <label for="country" class="col-sm-3 control-label">Category Name<span>*</span></label>
                       <div class="col-sm-9">
                          <select class="form-control" name="category_id" id="category_id">
                                <?php $__currentLoopData = $userss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option  value="<?php echo e($user_info->id); ?>"><?php echo e($user_info->category_Name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
	        <div class="form-group <?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                  <label for="email" class="col-sm-3 control-label">SubCategory Name<span>*</span></label>
                    <div class="col-sm-9">
                         <?php echo Form::text('subcategory_Name',$value= null, $attributes = ['class'=>'form-control','placeholder'=>'Subcategory Name','required'=>true]); ?>

                      <?php if($errors->has('subcategory_Name')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('subcategory_Name')); ?></strong>
                        </span>
                      <?php endif; ?>
                  </div>
                </div>






