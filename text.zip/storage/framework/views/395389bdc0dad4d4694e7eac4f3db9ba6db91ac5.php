<?php $__env->startSection('content'); ?>
    <section class="content">
        <h1 class="text-center">Dashboard</h1>
        <hr>
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12">
                <a href="">
                    <div class="info-box">
                        <span class="info-box-icon bg-teal"> <i class="fa fa-comments" aria-hidden="true"></i></span>
                        <div class="info-box-content">
                            <h3>Posts </h3>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <a href="">
                    <div class="info-box">
                        <span class="info-box-icon bg-black"><i class="fa fa-users"></i></span>
                        <div class="info-box-content">
                            <h3>Manage users</h3>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <a href="">
                    <div class="info-box">
                        <span class="info-box-icon bg-yellow"> <i class="fa fa-bar-chart" aria-hidden="true"></i></span>
                        <div class="info-box-content">
                            <h3>Statistics</h3>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <a href="<?php echo e(url('/logout')); ?>">
                    <div class="info-box">
                        <span class="info-box-icon bg-red"><i class="fa fa-sign-out"></i></span>
                        <div class="info-box-content">
                            <h2>Logout </h2>
                        </div>
                    </div>
                </a>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>