<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2015-2017 <a href="<?php echo e(url('/')); ?>"><?php echo e(env('APP_NAME','ASK-Bahrain')); ?></a>.</strong> All rights
    reserved.
</footer>